/*=======================================================================
|      Source code:  Table.java
|
|            Class:  Table
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac Table.java
|
|          Purpose: Provides and methods and constructors to print a customized
|                   table with an n number of elements. 
|                      
|
|    Inherits From:  none
|
|       Interfaces:  none
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public int[][] getTable() ;
|               public Table(int number, int[] arrayOfFibs) ;
|               
|  *==========================================================================*/
public class Table 
{
  
    int[][] chart ;
    
    /*---------------------------- getTable ----------------------------
        | method getTable()
        |
        |  Purpose: gets the array with a size customized to the number of data
        |           entries to be inputted to the table
        |
        |  @param none
        |
        |  @return chart - the array
        *-------------------------------------------------------------------*/
    public int[][] getTable() 
    {
        return chart ;
    }
   
    /*---------------------------- Table ----------------------------
        | Constructor Table()
        |
        |  Purpose: Creates a table with customized dimensions.
        |
        |  @param int number - the number of elements in the table
        |             arrayOfFibs - array of elements to be printed in the table
        |
        |  @return none
        *-------------------------------------------------------------------*/
   public Table(int number, int[] arrayOfFibs) 
   {
      
        int sizeOfChart = (int) Math.sqrt(number) + 1 ;
        
        if (sizeOfChart <= 10) {
            chart = new int[(int) Math.sqrt(number) + 1] /** adds one since
             most numbers don't square root evenly*/ 
        [(int) Math.sqrt(number) + 1] ;
        } else {
            chart = new int[10][10] ;
        }
        int counter = 0;

        for (int i = 0; i < chart.length; i++) {
            for (int j = 0; j < chart[0].length; j++) {
                if (counter < arrayOfFibs.length) {
                    chart[i][j] = arrayOfFibs[counter] ;
                    counter++ ;
                }
            }
        }   
    }
}
  