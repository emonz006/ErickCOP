/*=======================================================================
|      Source code:  FibSequence.java
|
|            Class:  FibSequence
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac FibSequence.java
|
|          Purpose:  Provides methods and constructors to calculated the next
|                    fibonacci number recursively.
|                      
|
|    Inherits From:  none
|
|       Interfaces:  Sequence.java
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public boolean next(int number) ;
|               public int[] primeNumCheck(int startPoint, int numOfPrimes) ;
|               
|  *==========================================================================*/
public class FibSequence implements Sequence
{
   long number = 1 ; // first fib number
   long fibNum = 0 ;
   
   /*---------------------------- startNext ----------------------------
        | method startNext()
        |
        |  Purpose: gets the next fibonacci number if it is less than the third.
        |
        |  @param none
        |
        |  @return fibNum - the fibonacci number
        *-------------------------------------------------------------------*/
   public long startNext()
   {  

            fibNum = 1 ;
            return fibNum ;
        
    }   

    /*---------------------------- restNext ----------------------------
        | method restNext()
        |
        |  Purpose: gets the next fibonacci number if it is greater than the 
        |  third.
        |
        |  @param long number - the number of the fibonacci number.
        |
        |  @return fibNum - the fibonacci number
        *-------------------------------------------------------------------*/
    public long restNext(long number)
   {  
        //first fib number
        if (number <= 2) 
        { 
            return 1 ;
        }
        else 
        { 
            long fibnum = ( restNext(number - 1) ) + ( restNext(number - 2) ) ;
            
            return fibnum;
        } 
        
    }   
   
    /*---------------------------- next ----------------------------
        | method next()
        |
        |  Purpose: gets the next fibonacci number
        |
        |  @param none
        |
        |  @return fibNum - the next fibonacci number (starting at 1)
        *-------------------------------------------------------------------*/
   public long next()
   {
       if(number <= 2)
       {
           startNext() ;
           number ++ ;
       }
       else
       {
           fibNum = restNext(number) ;
           this.number ++ ;
       }
       return fibNum ;
   }
   
}