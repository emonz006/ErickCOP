/*=======================================================================
|      Source code:  StopWatch.java
|
|            Class:  StopWatch
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac StopWatch.java
|
|          Purpose:  Provides for methods and constructors to make and use a 
|                    a stop watch. 
|                      
|
|    Inherits From:  none
|
|       Interfaces:  none
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public StopWatch() ;
|               public void start() ;
|               public void stop() ;
|               public long getElapsedTime() ;
|               public void reset() ;
|
|   *i recieved this class from my textbook (The Big Java)*
|            
|  *==========================================================================*/
public class StopWatch
{
    private long elapsedTime ;
    private long startTime ;
    private boolean isRunning ;
    
    /*---------------------------- StopWatch ----------------------------
        | Constructor StopWatch()
        |
        |  Purpose: creates a stop watch object.
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public StopWatch()
    {
        reset() ;
    }
    
    /*---------------------------- Start ----------------------------
        | method Start()
        |
        |  Purpose: starts the stopwatch
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public void start()
    {
        if (isRunning) { return; }
        isRunning = true ;
        startTime = (System.currentTimeMillis() / 6000) ;
    }
    
    /*---------------------------- Stop ----------------------------
        | method Stop()
        |
        |  Purpose: stops the stopwatch
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public void stop()
    {
        if (!isRunning) {return ; }
        isRunning = false;
        long endTime = (System.currentTimeMillis() / 6000) ;
        elapsedTime = elapsedTime + endTime - startTime ;
    }
    
    /*---------------------------- Start ----------------------------
        | method getElapsedTime()
        |
        |  Purpose: gets the elapsed time between the start and finish times
        |
        |  @param none
        |
        |  @return elapsedTime - the time elapsed between the start and end pts.
        *-------------------------------------------------------------------*/
    public long getElapsedTime()
    {
        if(isRunning)
        {
            long endTime = System.currentTimeMillis();
            return elapsedTime + endTime - startTime;
        }
        else
        {
            return elapsedTime ;
        }
    }
    
    /*---------------------------- reset ----------------------------
        | method reset()
        |
        |  Purpose: resets the stop watch.
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public void reset()
    {
        elapsedTime = 0 ;
        isRunning = false ;
    }
}