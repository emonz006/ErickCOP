/*=============================================================================  
|       Source code:  FibDemo.java
|            Author:  Erick Monzon
|        Student ID:  5924838
|        Assignment:  Program #6 - Fibonacci Sequence
|  
|            Course:  COP 3337 (Intermediate Programming) 
|           Section:  U06 
|        Instructor:  William Feild  
|          Due Date:  4/20/2017, by the end of class 
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|       Language:  Java
|       Compile/Run:  Both java source code files must be in the same directory
|         javac FibDemo.java javac InvalidInputException.java 
|         javac FibSequence.java javac FastFibSequence.java 
|         javac LoopFibSequence.java javac Table.java
|         javac StopWatch.java  javac Sequence.java
|         
|         java FibDemo (Inputfilename.txt) (outputfilename.txt)

|       The command line accepts two text files with the first representing the 
|       input file.txt  and the second 
|       indiacating the output file.txt. For a formatted table, copy and paste 
|       the output from notepad, to another text editor such as microsoft word.
| 
|  +----------------------------------------------------------------------------  
|  
|       Description:  A class designed to accept and validate command line input
|                    and tests the FastFibSequence, FibSequence, 
|                    and LoopFibSequenceclasses by printing three 
|                    tables containing an n number
|                    of fibonacci numbers which is determined by the first 
|                    integer in an input text file. It prints these three tables
|                    to a user specific output text file.
|                  
|             Input:  Command Line input that are text files with the first typed
|                     being the input file of where to collect the disired
|                     number of fibonacci numbers and the second 
|                     text file being the amount of prime numbers 
|                     wished to be collected.
|  
|            Output:  This program outputs three tables to the output file
|                     displaying an n amount of fibonacci numbers as 
|                     requested by the input file.
|                     
|
|  
|           Process:  Program will use the constructors/methods provided by the
|                     Table, FastFibSequence, FibSequence, LoopFibSequence, 
|                     Sequence, and StopWatch classes
|  
| Instance Methods:  
|		
|              
|   Required Features Not Included:  The StopWatch time collection does not 
|   work properly and just outputs 0.
|                
|  
|        Known Bugs:  When printing the table, all empty spaces are printed as 
|                     0's, There has been outofbounds exceptions when running
|                     due to the FastFibSequence.java class.
|  
|  *==========================================================================*/
import java.io.*; /*import of all the import/output java class to aid with 
                   exception handling and file input as well as output*/   
import java.util.NoSuchElementException; /*import of the NoSuchElementException
                  class to catch cases where there is either an empty file, 
                  or no positive integer located in the file*/
import java.util.Scanner; /*Allows for file reading*/
import java.io.PrintWriter; /*Allows for file output*/

public class FibDemo {

    
    public static void main(String args[]) {
        for (int i = 0; i < args.length; i++) {
            try {
                StopWatch timeOne = new StopWatch();
                StopWatch timeTwo = new StopWatch();
                StopWatch timeThree = new StopWatch();

                String inputFile = args[0];
                File input = new File(inputFile);
                Scanner in = new Scanner(input);

                String outputFile = args[1];
                File output = new File(outputFile);
                PrintWriter out = new PrintWriter(outputFile);
                try
                {
                if (in.hasNextInt()) {
                    int number = in.nextInt();
                    FibSequence recursiveFibSequence = new FibSequence();
                    int[] arrayOfFibs = new int[number];
                    timeOne.start();
                    for (int counter = 0; counter < number; counter++) {
                        arrayOfFibs[counter] = (int) recursiveFibSequence.next();
                    }
                    timeOne.stop();
                    Table tableOne = new Table(number, arrayOfFibs);

                    int[] arrayOfFastFibs = new int[number];
                    FastFibSequence fastFibSequence
                            = new FastFibSequence(number);
                    timeTwo.start();
                    for (int counter = 0; counter < number; counter++) {
                        arrayOfFastFibs[counter] = (int) fastFibSequence.next();
                    }
                    timeTwo.stop();
                    Table tableTwo = new Table(number, arrayOfFastFibs);

                    LoopFibSequence loopFibSequence = new LoopFibSequence();
                    int[] arrayOfLoopFibs = new int[number];
                    timeThree.start();
                    for (int counter = 0; counter < number; counter++) {
                        arrayOfFibs[counter] = (int) loopFibSequence.next();
                    }
                    timeThree.stop();
                    Table tableThree = new Table(number, arrayOfLoopFibs);

                    for (int counter = 3; counter <= 3; counter++) {
                    }
                    for (int k = 0; k < tableOne.getTable().length; k++) {
                        for (int j = 0; j < tableOne.getTable()[0].length; j++) {
                            out.printf("%10s", tableOne.getTable()[k][j]); 
                        } 
                    }
                    out.println("\n" + "Time Elapsed: " + 
                                timeOne.getElapsedTime() + "\n");

                    for (int k = 0; k < tableTwo.getTable().length; k++) {
                        for (int j = 0; j < tableTwo.getTable()[0].length; j++) {
                            out.printf("%10s", tableTwo.getTable()[k][j]); 
                        }      
                    }
                    out.println("\n" + "Time Elapsed: " 
                                + timeTwo.getElapsedTime() + "\n");

                    for (int k = 0; k < tableThree.getTable().length; k++) {
                        for (int j = 0; j < tableThree.getTable()[0].length; j++) {
                            out.printf("%10s", tableThree.getTable()[k][j]); 
                        } 
                    }
                    out.println("\n" + "Time Elapsed: " 
                                + timeThree.getElapsedTime() + "\n");
                }
                if (in.nextInt() < 1 || in.nextInt() > 40) {
                    throw new InvalidInputException("Input is either too"
                            + "small or too large.");
                }    
                } finally
                {
                    out.close();
                    in.close();
                }
            } catch (IOException exception) {
                System.out.println("File not found.");;
            } catch (NoSuchElementException exception) {
                exception.printStackTrace();
            }

        }            
    }
}
