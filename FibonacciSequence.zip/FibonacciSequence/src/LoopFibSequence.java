/*=======================================================================
|      Source code:  LoopFibSequence.java
|
|            Class:  LoopFibSequence
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac LoopFibSequence.java
|
|          Purpose:  Provides methods and constructors to calculated the next
|                    fibonacci number iteratively.
|                      
|
|    Inherits From:  none
|
|       Interfaces:  Sequence.java
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public boolean next(int number) ;
|               public int[] primeNumCheck(int startPoint, int numOfPrimes) ;
|               
|  *==========================================================================*/
public class LoopFibSequence implements Sequence
{
    long number = 1 ;
    
    /*---------------------------- next ----------------------------
        | method next()
        |
        |  Purpose: gets the next fibonacci number calculated iteratively.
        |
        |  @param none
        |
        |  @return newValue - the next fibonacci number.
        *-------------------------------------------------------------------*/
    public long next()
    {
        if (number <= 2) 
        { 
            number ++ ;
            return 1 ; 
        }
        else
        {
            long olderValue = 1 ;
            long oldValue = 1 ;
            long newValue = 1 ;
            
            for (int i = 3 ; i <= number ; i++)
            {
                newValue = oldValue + olderValue ;
                olderValue = oldValue ;
                oldValue = newValue ;
                number ++ ;
            }
            return newValue ;
        }
    }
}