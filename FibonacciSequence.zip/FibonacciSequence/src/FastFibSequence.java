/*=======================================================================
|      Source code:  FastFibSequence.java
|
|            Class:  FastFibSequence
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac FastFibSequence.java
|
|          Purpose:  Provides methods and constructors to calculated the next
|                    fibonacci number "fast recursviely" using an array.
|                      
|
|    Inherits From:  none
|
|       Interfaces:  Sequence.java
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public long next() ;
|               public FastFibSequence(long number) ;
|               
|  *==========================================================================*/
public class FastFibSequence implements Sequence
{
    long number = 0 ;
    int pointer = 0 ;
    int counter = 0 ;
    int[] arrayOfFibs ;
    
    /*---------------------------- next ----------------------------
        | method next()
        |
        |  Purpose: gets the next fibonacci number calculated using an array.
        |
        |  @param none
        |
        |  @return arrayOfFib[counter - 1] - the fibonacci number
        *-------------------------------------------------------------------*/
    public long next()
    {
        this.populateArray() ;
        counter ++ ;
        return arrayOfFibs[counter - 1] ;
    }
    
    /*---------------------------- populateArray ----------------------------
        | method next()
        |
        |  Purpose: populates an array of fibonacci numbers calculated using the
        |           array.
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public void populateArray()
    {
        
        for (pointer = 0 ; pointer < arrayOfFibs.length ; pointer ++)
        {
        if (pointer <= 1) 
        { 
           arrayOfFibs[pointer] = 1 ;   
        }
        else 
        { 
            arrayOfFibs[pointer] = arrayOfFibs[pointer - 1] 
                    + arrayOfFibs[pointer - 2] ;
        }   

        }
    }
    
    /*---------------------------- FastFibSequence ----------------------------
        | Constructor FastFibSequence(long number)
        |
        |  Purpose: creates a FastFibSequence object that specifies the number of
        |           fibonacci numbers to be calculated.
        |
        |  @param long number - the number of fibonacci numbers to be calculated
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public FastFibSequence(long number)
    {
        this.number = number ;
        arrayOfFibs = new int[ (int)number ] ;
    } 
}