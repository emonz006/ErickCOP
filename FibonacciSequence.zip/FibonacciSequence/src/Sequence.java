/*=======================================================================
|      Source code:  Sequence.java
|
|            Class:  Sequence
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac Sequence.java
|
|          Purpose:  Interface that requires classes implementing it to 
|                    initialize the next() method. It is type long because
|                    fibonacci numbers get very large, very rapidly.
|                      
|
|    Inherits From:  none
|
|       Interfaces:  none
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public long next() ;
|               
|  *==========================================================================*/
public interface Sequence 
{
    /*---------------------------- next ----------------------------
        |  Method next(number)
        |
        |  Purpose: Gets the next number in the sequence.
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    long next() ; 
}
