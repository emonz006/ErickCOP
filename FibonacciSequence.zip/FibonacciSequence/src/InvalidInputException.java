/*=======================================================================
|      Source code:  InvalidInputException.java
|
|            Class:  InvalidInputException
|
|           Author:  Erick Monzon
|       Student ID:  5924838
|       Assignment:  Program #6 - Fibonacci Sequence
|  
|           Course:  COP 3337 (Intermediate Programming)
|          Section:  U06
|       Instructor:  William Feild  
|         Due Date:  4/20/2017, by the end of class  
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|         Language:  Java
|      Compile/Run:  
| 	  javac InvalidInputException.java
|
|          Purpose:  extends the IllegalArgumentException class to include
|                    the InputInvalid Exception error, or when the number 
|                    inputted is either too large or too small.
|                      
|
|    Inherits From:  RuntimeException.java
|
|       Interfaces:  
|
|  +-----------------------------------------------------------------------
|
|        Constants:  
|		None
|
| +-----------------------------------------------------------------------
|
|    Constructors:  
|		
|			
|    Class Methods:  
|		
|		
| Instance Methods:  
|		public InvalidInputException() ;
|               public InvalidInputException(String message) ;
|               
|  *==========================================================================*/
public class InvalidInputException extends IllegalArgumentException
{
    /*---------------------------- InvalidInputException ----------------------------
        | method next()
        |
        |  Purpose: constructs and InvalidInputException
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public InvalidInputException() {}
    
    /*---------------------------- InvalidInputException ----------------------------
        | method next()
        |
        |  Purpose: displays the same message of the super class' exception.
        |
        |  @param none
        |
        |  @return none
        *-------------------------------------------------------------------*/
    public InvalidInputException(String message)
    {
        super(message) ;
    }
}