//package PiCalculator ; 
/*=============================================================================  
|   Source code:  ComputePI.java
|           Author:  Erick Monzon 
|     Student ID:  5924838  
|    Assignment:  Program #1- Computing Pi
|  
|            Course:  COP 3337 (Intermediate Programming) 
|           Section:  U06
|        Instructor:  William Feild  
|        Due Date:  1/19/2017, at the beginning of class
|
|	I hereby certify that this collective work is my own
|	and none of it is the work of any other person or entity.
|	______________________________________ [Signature]
|  
|        Language:  Java 
|  Compile/Run:
| 	javac ComputePI.java  
|	java ComputePI
| 
|  +---------------------------------------------------------------------------  
|  
|  Description:  
|    Correctly calculates the first 6 significant digits of Pi using  
|    the provided infinate series:
|          ( π / 4 ) = 1 - ( 1 / 3 ) + ( 1 / 5 ) - ( 1 / 7 ) + ( 1 / 9 ) - ...    
|
|        Input:  No User Input  
|                   
|  
|     Output:  
|     The computed value of pi (using the formula ^), The expected result 
|    (using the library constant value of π), and the number of iterations 
|    it took to calculate π within 6 significant figures of accuracy. 
|
|     Process: 
|    Calculates Pi to 6 significant digits using the infinate series 
|    provided: 
|            ( π / 4 ) = 1 - ( 1 / 3 ) + ( 1 / 5 ) - ( 1 / 7 ) + ( 1 / 9 ) - ...
|    This series progressively stabilizes as more numbers are added but
|    calculates (π/4) so in order to get π we need to multiply this whole series
|    by 4. This new series can be represented by the formula: 
|              Math.pow(-1, (i + 2) )  * ( 4 * ( 1.0 / ( 2.0 * i + 1.0) ) 
|    where "i" represents the iteration number being ran. Using this knowledge,
|    a while loop was crafted that would add a new number to the infinate
|    series each iteration therefore stabilizing it up until it fully 
|    stabilized up to 6 significant digits. We know this because each
|    iteration of the while loop would subtract the current calculation of 
|    pi by the previous and using this change would allow us to see such 
|    stabilization. The loop is commanded to stop once Pi has been "calculated" 
|    to 6 correct significant digits.
|
|   Required Features Not Included: All features included
|               
|  
|   Known Bugs:  None   
|  *==========================================================================*/
public class ComputePI 
{
/*---------------------------- main ----------------------------
        |  Method main(args)
        |
        |  Purpose:  Calcualates Pi within 6 significant figures of accuracy
        |
        |  @param  args - command-line input not used
        |
        |  @return  void - none
        *-------------------------------------------------------------------*/    
public static void main(String[] Args)
{
                        /* instance variables/declare and initialize */
    
    /* Current Iteration of Pi */
    double currPi = 0 ; 
    
    /* Previous Iteration of Pi */
    double prevPi = 0 ; 
   
    /*Counts the instance number and influences the Pi formula based on that*/
    int i = 0 ;
  
    /*Stores difference between current Pi and the previous iteration of Pi*/
    double difference = 0 ;
    
    double sixSigFigs = 0.000001 ;
   
                        /* Pi Calculating Loop */
                        
    boolean done = false ; 
    while(done == false)
    {
        prevPi = currPi ;
        
        /*Calculates the new currPi (if confused by formula refer to "Process"*/
        currPi += Math.pow(-1, (i + 2))  * 4 * (1.0 / ( 2.0 * i + 1.0)) ; 
        
        difference = currPi - prevPi ;
        i++ ; 
        
            /**Checks the change in Pi to see if the current Pi is accurate to 6 
            significant figures */
            if( difference <= sixSigFigs && difference > 0) 
                {
                    done = true ;
                }
    }
    
                        /* Output Results */
    
    System.out.println("Calculated value for Pi: " + currPi) ;
    
    System.out.println("Expected value for Pi: " + Math.PI);
    
    System.out.println("Number of instances taken to reach six significant "
            + "figures of accuracy: " + i) ;

}

}